def create_fire() -> str:
    """
    create fire element

    :return: Description of the created fire element
    :rtype: str
    """
    return "Fire element created"


def create_water() -> str:
    """
    create water element

    :return: Description of the created water element
    :rtype: str
    """
    return "Water element created"


def create_earth() -> str:
    """
    create earth element

    :return: Description of the created earth element
    :rtype: str
    """
    return "Earth element created"


def create_air() -> str:
    """
    create air element

    :return: Description of the created air element
    :rtype: str
    """
    return "Air element created"
