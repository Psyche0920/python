from .elements import create_fire, create_water

__all__ = ["create_fire", "create_water"]

__version__ = "1.0.0"
__author__ = "Master Pythonicus"
